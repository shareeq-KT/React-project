import React from "react";
import './ShowcaseLayout.css'
import Selection from 'react-ds';
import GridLayout from 'react-grid-layout';

export default class ShowcaseLayout extends React.PureComponent {
  
  constructor() {
    super();
 
    this.state = {
      ref: null,
      elRefs: [],
      selectedElements: [], // track the elements that are selected
    };
  }
  
  handleSelection = (indexes) => {
    this.setState({
      selectedElements: indexes,
    });
  };
 
  getStyle = (index) => {
    if (this.state.selectedElements.indexOf(index) > -1) {
      // Selected state
      return {
        background: '#2185d0',
        border: '5px solid #2185d0',
        color: 'white',
        opacity: '1'
      };
    }
    return {};
  };
  
  addElementRef = (ref) => {
    const elRefs = this.state.elRefs;
    elRefs.push(ref);
    this.setState({
      elRefs,
    });
  };
  
  renderSelection() {
    if (!this.state.ref || !this.state.elRefs) {
      return null;
    }
    return (
      <Selection
      target={ this.state.ref}
      elements={ this.state.elRefs }
      onSelectionChange={ this.handleSelection }
      ignoreTargets= {['img']}
      style={ this.props.style }
      />
      );
  }
  
  allstorage(){
    var values = [],
    pics = [],
		keys = Object.keys(localStorage),
		i = keys.length;
    
		while(i--) {
      pics = JSON.parse(localStorage.getItem(keys[i]))
			values.push( pics );
    }
    
    return values;
  }
  
  render() {
    var images = [],
    descript = [];
    var photos = this.allstorage();
    for (let index = 0; index < photos.length; index++) {
      descript.push(photos[index].user)
      images.push(photos[index].imageFile)
    }
    
    return (
      <div>
        <div ref={ (ref) => { this.setState({ ref }); } } className='item-container'>
          <GridLayout className="layout" width={1315} cols={5} >
            {images.map((value, index) => (      
              <div key={`item-${value}`} className="item" ref={ this.addElementRef } style={ this.getStyle(index) } data-grid={{x:index , y: 1, w: 1, h: 1}} >
                <img className={`item-${value}`} src= {images[index]} alt= "" ></img>
                <div class="content">
                  <div> { descript[index] } </div>
                </div>
              </div>            
            ))}
          </GridLayout>
          { this.renderSelection() }
        </div>
      </div>
    )
  }
}
