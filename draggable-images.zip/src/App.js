import React from 'react';
import './App.css';
import Main from './components/main/main.jsx';


function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
} 

export default App;
